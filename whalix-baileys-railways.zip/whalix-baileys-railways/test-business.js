// test-business.js - VERSION WHATSAPP BUSINESS
const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const qrcode = require('qrcode-terminal');

async function connectWhatsApp() {
    console.log('=================================');
    console.log('🚀 DÉMARRAGE DE WHALIX (Business)');
    console.log('=================================\n');
    
    // Version Baileys
    const { version } = await fetchLatestBaileysVersion();
    
    const { state, saveCreds } = await useMultiFileAuthState('whalix_session_business');
    
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        version, // Version importante pour Business
        connectTimeoutMs: 60000, // Plus de temps pour Business
        defaultQueryTimeoutMs: undefined,
        keepAliveIntervalMs: 10000,
        emitOwnEvents: true,
        fireInitQueries: false
    });
    
    sock.ev.on('connection.update', async (update) => {
        const { connection, qr, lastDisconnect } = update;
        
        if(qr) {
            console.log('📱 SCANNE AVEC WHATSAPP BUSINESS:\n');
            qrcode.generate(qr, { small: true });
        }
        
        if(connection === 'open') {
            console.log('\n✅ SUCCÈS ! CONNECTÉ !');
            console.log('Numéro:', sock.user?.id);
            
            // Test immédiat
            console.log('📤 Envoi message de test...');
            try {
                await sock.sendMessage(sock.user.id, { 
                    text: '✅ Whalix connecté avec succès!' 
                });
                console.log('✅ Message test envoyé!');
            } catch(e) {
                console.log('⚠️ Erreur envoi test:', e.message);
            }
        }
        
        if(connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== 401;
            if(shouldReconnect) {
                console.log('🔄 Reconnexion dans 5 secondes...');
                setTimeout(connectWhatsApp, 5000);
            }
        }
    });
    
    sock.ev.on('creds.update', saveCreds);
    
    sock.ev.on('messages.upsert', async (m) => {
        const msg = m.messages[0];
        if (!msg.key.fromMe && msg.message) {
            console.log('\n💬 MESSAGE REÇU !');
            console.log('De:', msg.pushName);
            console.log('Message:', msg.message.conversation);
        }
    });
}

connectWhatsApp().catch(console.error);